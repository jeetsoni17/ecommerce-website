<!DOCTYPE html>
<html>
<head>
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,400;1,300&display=swap" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
</head>
<body>
<?php include('config.php'); ?>
<!--#42dcff	--> 

<div class="row">
  <div class="upcolumn">

<div class="mySlides fade">
  <img src="imgs/img1.jpg" class="slides-img">
</div>
<div class="mySlides fade">
  <img src="imgs/img2.jpg" class="slides-img">
</div>
<div class="mySlides fade">
  <img src="imgs/img3.jpg" class="slides-img">
</div><!-- 
<div class="mySlides fade">
  <img src="imgs/img4.jpg" class="slides-img">
</div>
<div class="mySlides fade">
  <img src="imgs/img5.jpg" class="slides-img">
</div>
<div class="mySlides fade">
  <img src="imgs/img6.jpg" class="slides-img">
</div> -->

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span> 
</div>

</div>
</div>

<div class="sub-title">Headphones <a href="fruits.php">(View All)</a>
<hr></div>
<div class="row">
<?php
   	$sql = "SELECT * FROM products where type='Fresh Fruits' LIMIT 5";
   	$result = $conn->query($sql);
   	$resultset = array();
   	// output data of each row into resultset
    while($row = $result->fetch_assoc()) 
    {
       	$resultset[] = $row;
    }
   	foreach ($resultset as $r)
   	{

   		echo "<div class='columns'>
   		  <div class='card'>
   		    	<div class='product-imgs'><img src='$r[img]'></div>
   		    	<h3>$r[name]</h3>
   		      <button class='addCart'  id='$r[pid]' onclick='addQty(this)'><img src='icons/cart.png' class='card-icons-small' id='addcart'>Add</button>  
   		      <div class='cost'>₹$r[cost]</div>
   		  </div>
   		</div>";
   	}
?>
</div>
<br>

<div class="sub-title">Fresh Vegetables <a href="veggies.php">(View All)</a>
<hr></div>
<div class="row">
<?php
   	$sql = "SELECT * FROM products where type='Fresh Vegetables' LIMIT 5";
   	$result = $conn->query($sql);
   	$resultset = array();
   	// output data of each row into resultset
    while($row = $result->fetch_assoc()) 
    {
       	$resultset[] = $row;
    }
   	foreach ($resultset as $r)
   	{

   		echo "<div class='columns'>
        <div class='card'>
            <div class='product-imgs'><img src='$r[img]'></div>
            <h3>$r[name]</h3>
            <button class='addCart'  id='$r[pid]' onclick='addQty(this)'><img src='icons/cart.png' class='card-icons-small' id='addcart'>Add</button>  
            <div class='cost'>₹$r[cost]</div>
        </div>
      </div>";
   	}
?>
</div>
<br>

<div class="sub-title">Pulses <a href="pulses.php">(View All)</a>
<hr></div>
<div class="row">
<?php
   	$sql = "SELECT * FROM products where type='Pulses' LIMIT 5";
   	$result = $conn->query($sql);
   	$resultset = array();
   	// output data of each row into resultset
    while($row = $result->fetch_assoc()) 
    {
       	$resultset[] = $row;
    }
   	foreach ($resultset as $r)
   	{

   		echo "<div class='columns'>
   		  <div class='card'>
   		    	<div class='product-imgs'><img src='$r[img]'></div>
   		    	<h3>$r[name]</h3>
   		      <button class='addCart'  id='$r[pid]' onclick='addQty(this)'><img src='icons/cart.png' class='card-icons-small' id='addcart'>Add</button>  
   		      <div class='cost'>₹$r[cost]</div>
   		  </div>
   		</div>";
   	}
?>
</div>
<br>

<div class="sub-title">Cereals <a href="cereals.php">(View All)</a>
<hr></div>
<div class="row">
<?php
   	$sql = "SELECT * FROM products where type='Cereals' LIMIT 5";
   	$result = $conn->query($sql);
   	$resultset = array();
   	// output data of each row into resultset
    while($row = $result->fetch_assoc()) 
    {
       	$resultset[] = $row;
    }
   	foreach ($resultset as $r)
   	{

   		echo "<div class='columns'>
   		  <div class='card'>
   		    	<div class='product-imgs'><img src='$r[img]'></div>
   		    	<h3>$r[name]</h3>
   		      <button class='addCart'  id='$r[pid]' onclick='addQty(this)'><img src='icons/cart.png' class='card-icons-small' id='addcart'>Add</button>  
   		      <div class='cost'>₹$r[cost]</div>
   		  </div>
   		</div>";
   	}
?>
</div>
<br>

<div class="footer">
  <h2>Footer</h2>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 2 seconds
}

function addQty(x)
{
	var ids = x.id;
	window.location.href = "addCart.php?pid="+ids+"&qty=1";
}
</script>

</body>
</html>
