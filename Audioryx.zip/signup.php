<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,400;1,300&display=swap" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
    <link href="css/login.css" rel="stylesheet">
</head>
<body>
<?php include('config.php'); 
// REGISTER USER
if (isset($_POST['reg_user'])) {
    // receive all input values from the form
    $usern = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $password_1 = mysqli_real_escape_string($conn, $_POST['password_1']);
    $password_2 = mysqli_real_escape_string($conn, $_POST['password_2']);
  
    // form validation: ensure that the form is correctly filled ...
    // by adding (array_push()) corresponding error unto $errors array
    if (empty($usern)) { array_push($errors, "Username is required"); }
    if (empty($email)) { array_push($errors, "Email is required"); }
    if (empty($phone)) { array_push($errors, "Phone no. is required"); }
    if (empty($password_1)) { array_push($errors, "Password is required"); }
    if ($password_1 != $password_2) {
      array_push($errors, "The two passwords do not match");
    }
  
    // first check the database to make sure 
    // a user does not already exist with the same username and/or email
    $user_check_query = "SELECT * FROM users WHERE username='$usern' OR email='$email'  OR phone='$phone' LIMIT 1";
    $result = mysqli_query($conn, $user_check_query);
    $row = mysqli_fetch_assoc($result);
    
    if ($row) { // if user exists
      if ($row['username'] === $usern) {
        array_push($errors, "Username already exists");
      }
      if ($row['phone'] === $phone) {
        array_push($errors, "Phone no. already exists");
      }
      if ($row['email'] === $email) {
        array_push($errors, "Email already exists");
      }
    }
  
    // Finally, register user if there are no errors in the form
    if (count($errors) == 0) {
        $pass = md5($password_1);//encrypt the password before saving in the database
  
        $query = "INSERT INTO users (username, phone, email, password) 
                  VALUES('$usern', '$phone', '$email','$pass')";
        mysqli_query($conn, $query);
        $_SESSION['user'] = $usern;
        header('location: index.php');
    }
  }
?>

<div class="row">
</div><br><br>
<div class="sub-title" style="font-size: 15px;"><p><a href="index.php">Home</a> <a style="color:grey;"> > Sign up</a></p>
<hr></div>

  <form class="center1" method="post" action="signup.php">
  	<?php include('errors.php'); ?>
      <h2>Sign Up</h2>
  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" value="<?php echo $user; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php echo $email; ?>">
  	</div>
    <div class="input-group">
  	  <label>Phone No.:</label>
  	  <input type="text" name="phone" value="<?php echo $phone; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Register</button>
  	</div>
  	<p>
  		Already a member? <a href="login.php" class="links">Sign in</a>
  	</p>
  </form>

<div class="footer">
  <h2>Footer</h2>
</div>
</body>
</html>